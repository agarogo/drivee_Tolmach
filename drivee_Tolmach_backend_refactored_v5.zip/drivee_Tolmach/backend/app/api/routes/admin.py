from __future__ import annotations

from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Depends, Query as ApiQuery
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, require_admin
from app.api.utils import run_to_out
from app.models import Query, User
from app.query_execution.benchmarks import BENCHMARK_PRESETS
from app.query_execution.service import get_query_cache_stats, get_query_execution_summary, list_query_execution_audits
from app.reports import get_scheduler_summary, list_report_runs
from app.schemas import BenchmarkPresetOut, LogOut, QueryExecutionAuditOut, QueryExecutionCacheStatsOut, QueryExecutionSummaryOut, SchedulerSummaryOut, ScheduleRunOut


router = APIRouter(prefix="/admin", tags=["Admin monitoring"])


@router.get("/logs", response_model=list[LogOut])
async def admin_logs(
    user_email: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> list[LogOut]:
    stmt = select(Query, User.email).outerjoin(User, User.id == Query.user_id)
    if user_email:
        stmt = stmt.where(User.email.ilike(f"%{user_email}%"))
    if date_from:
        stmt = stmt.where(Query.created_at >= datetime.fromisoformat(date_from))
    if date_to:
        stmt = stmt.where(Query.created_at <= datetime.fromisoformat(date_to))
    rows = (await db.execute(stmt.order_by(Query.created_at.desc()).limit(300))).all()
    return [
        LogOut(
            id=query.id,
            created_at=query.created_at,
            user_email=email,
            question=query.natural_text,
            generated_sql=query.corrected_sql or query.generated_sql,
            status=query.status,
            duration_ms=query.execution_ms,
            prompt=str(query.interpretation_json),
            raw_response=str(query.sql_plan_json),
            error=query.error_message or query.block_reason,
        )
        for query, email in rows
    ]


@router.get("/query-execution/cache", response_model=QueryExecutionCacheStatsOut)
async def admin_query_execution_cache_stats(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> QueryExecutionCacheStatsOut:
    return QueryExecutionCacheStatsOut.model_validate(await get_query_cache_stats(db))


@router.get("/query-execution/summary", response_model=QueryExecutionSummaryOut)
async def admin_query_execution_summary(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> QueryExecutionSummaryOut:
    return QueryExecutionSummaryOut.model_validate(await get_query_execution_summary(db))


@router.get("/query-execution/audits", response_model=list[QueryExecutionAuditOut])
async def admin_query_execution_audits(
    limit: int = ApiQuery(default=50, ge=1, le=200),
    cache_hit: bool | None = None,
    status_filter: str | None = None,
    fingerprint: str | None = None,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> list[QueryExecutionAuditOut]:
    rows = await list_query_execution_audits(
        db,
        limit=limit,
        cache_hit=cache_hit,
        status=status_filter,
        fingerprint=fingerprint,
    )
    return [QueryExecutionAuditOut.model_validate(row) for row in rows]


@router.get("/query-execution/benchmarks/presets", response_model=list[BenchmarkPresetOut])
async def admin_query_execution_benchmark_presets(
    _: User = Depends(require_admin),
) -> list[BenchmarkPresetOut]:
    return [
        BenchmarkPresetOut(key=item.key, title=item.title, question=item.question)
        for item in BENCHMARK_PRESETS
    ]


@router.get("/scheduler/summary", response_model=SchedulerSummaryOut)
async def admin_scheduler_summary(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> SchedulerSummaryOut:
    return SchedulerSummaryOut.model_validate(await get_scheduler_summary(db))


@router.get("/scheduler/runs", response_model=list[ScheduleRunOut])
async def admin_scheduler_runs(
    limit: int = ApiQuery(default=50, ge=1, le=200),
    status_filter: str | None = None,
    report_id: UUID | None = None,
    schedule_id: UUID | None = None,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
) -> list[ScheduleRunOut]:
    rows = await list_report_runs(
        db,
        report_id=report_id,
        schedule_id=schedule_id,
        limit=limit,
    )
    if status_filter:
        rows = [row for row in rows if row.status == status_filter]
    return [await run_to_out(db, row) for row in rows]
