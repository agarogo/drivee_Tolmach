# Backend refactor v5

Что изменено:

- API теперь имеет каноничный prefix `/api/v1`; старые пути сохранены скрытыми из Swagger:
  - `/auth/login` продолжает работать
  - `/api/chats` продолжает работать
  - `/api/v1/...` показывается в FastAPI Docs
- Убраны wildcard imports из route-файлов. Вместо `from app.api.common import *` используются явные импорты.
- `app/api/common.py` оставлен только как compatibility re-export для старого кода.
- Добавлены слои:
  - `app/api/deps.py` — зависимости FastAPI
  - `app/api/utils.py` — сериализация ответов и helper-функции
  - `app/repositories/` — ownership/DB helpers
  - `app/services/query_flow.py` — бизнес-сценарий запросов и чатов
  - `app/services/export.py` — CSV export
- Добавлены API exception handlers с единым форматом ошибки:

```json
{
  "error": {
    "code": "...",
    "message": "...",
    "details": {},
    "request_id": "..."
  }
}
```

- Добавлен `RequestIDMiddleware`: каждый ответ получает `X-Request-ID` и `X-Process-Time-Ms`.
- Добавлены RBAC helpers `has_permission()` и `require_permission()` в `app/auth.py`.
- Добавлен `/queries/{id}/export.csv` и `/reports/{id}/export.csv`.
- Добавлены `backend/Makefile`, `backend/pyproject.toml`, `backend/requirements-dev.txt`, `backend/scripts/check_backend.sh`.
- Добавлен базовый eval-набор `backend/evals/nl_sql_cases.json`.
- Ollama в `docker-compose.yml` теперь запускается с GPU через `gpus: all`.

## Проверка на своей машине

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
```

Для GPU на Windows/Linux нужен установленный NVIDIA Container Toolkit и рабочая проверка:

```bash
docker run --rm --gpus all nvidia/cuda:12.4.1-base-ubuntu22.04 nvidia-smi
```

Если эта команда не видит GPU, Ollama тоже не сможет использовать GPU внутри Docker.
